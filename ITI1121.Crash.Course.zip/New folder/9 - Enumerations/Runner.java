class Runner {
	
	public static void main(String[] args) {
		
		Pokemon ivysaur = new Ivysaur();
		System.out.println(ivysaur.TYPE);
	}
}
