class Trainer implements Interactable {
	
	public void interact() {
		System.out.println("I challenge you to a battle!");
	}
}
