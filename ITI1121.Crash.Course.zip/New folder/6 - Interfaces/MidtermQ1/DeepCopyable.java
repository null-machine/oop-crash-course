/**
 * COPYRIGHTED MATERIAL -- DO NOT DISTRIBUTE
 *
 * @author Guy-Vincent Jourdan
 * @author Mehrdad Sabetzadeh 
 */


// DO NOT MODIFY THIS FILE

public interface DeepCopyable {
	DeepCopyable deepCopy();
} 