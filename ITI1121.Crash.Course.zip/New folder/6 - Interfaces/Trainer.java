class Trainer implements Interactable {
	
	@Override
	public void interact() {
		System.out.println("I challenge you to a battle!");
	}
}
