class Runner {
	
	public static void main(String[] args) {
		
		// none of these will work. why?
		
		// Pikachu pikachu = new Pikachu();
		// pikachu.TYPE = "Electric";
		
		// Pikachu pikachu = new Pikachu();
		// System.out.println("Pikachu has " + pikachu.health + " health.");
		
		// Ivysaur ivysaur = new Ivysaur();
		// ivysaur.health -= 10;
		// System.out.println("Ivysaur has " + ivysaur.getHealth() + " health remaining.");
		
		// Pokemon pokemon = new Pokemon(30, "Basic");
	}
}
